
package listaenlazada;

import vistas.operacionesNodo;

public class ListaEnlazada {

  
    public static void main(String[] args) {
        operacionesNodo o = new operacionesNodo();
        o.setVisible(true);
    }
    
}
