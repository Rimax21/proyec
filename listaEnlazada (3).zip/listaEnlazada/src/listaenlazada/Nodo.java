
package listaenlazada;

public class Nodo {
    public int dato;
    Nodo siguiente;
            
}
